import network.AjiraNetwork;;

public class Main {
    public static void main(String[] args) {
        AjiraNetwork agiraNet = new AjiraNetwork();
        agiraNet.startConsole();
    }
}
